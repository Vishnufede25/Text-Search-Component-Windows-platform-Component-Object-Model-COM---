
Write-Host "Running the C++ client:  searching for: inc in cpp h txt";
  

.\Debug\CppClient.exe "(\\+|-)?[[:digit:]]+" .\test h cpp cs txt


