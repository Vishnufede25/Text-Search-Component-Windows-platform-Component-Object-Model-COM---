// Test.cpp : Implementation of CTest

#include "stdafx.h"
#include "Test.h"
#include "_ITestEvents_CP.h"
#include <iostream>
#include <string>
#include "_ITestEvents_CP.h"


// CTest

STDMETHODIMP CTest::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* const arr[] = 
	{
		&IID_ITest
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CTest::PutString(BSTR str)
{
  CComBSTR bstr(str);
  std::wcout << "\n  Server received string \"" << bstr.m_str << "\"";
  Fire_Notify(bstr);
  return S_OK;
}


STDMETHODIMP CTest::GetString(BSTR* str)
{
  CComBSTR bstr(L"Server's message for client");
  *str = bstr;
  bstr.Detach();
  return S_OK;
}
