#pragma once
///////////////////////////////////////////////////////////////////////
//  BlockingQueueObj.h : BlockingQueue object    					 //
//	Language  : C++, COM											 //
//  Platform  : MSI, Windows 10 Professional						 //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////
#include <condition_variable>
#include <mutex>
#include <thread>
#include <queue>
#include <string>
#include <iostream>
#include <atlbase.h>
#include <atlsafe.h>
#include <sstream>
#include "../Cpp11-BlockingQueue/Cpp11-BlockingQueue.h"

class BlockingQueueObj {
public:
	BlockingQueueObj() {}
	CComBSTR getobj();
	BlockingQueue<CComBSTR> putobj();
	void getqueue(BlockingQueue<CComBSTR> q);
private:
	BlockingQueue<CComBSTR> bq;
};


CComBSTR BlockingQueueObj::getobj()
{
	CComBSTR returnstr = bq.deQ();
	return returnstr;
}

void BlockingQueueObj::getqueue(BlockingQueue<CComBSTR> q)
{
	bq = q;
}
BlockingQueue<CComBSTR> BlockingQueueObj::putobj()
{
	return bq;
}