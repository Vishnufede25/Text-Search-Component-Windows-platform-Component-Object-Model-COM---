

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Mon Jan 18 22:14:07 2038
 */
/* Compiler settings for PrFIleManager.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __PrFIleManager_i_h__
#define __PrFIleManager_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IFIleMgr_FWD_DEFINED__
#define __IFIleMgr_FWD_DEFINED__
typedef interface IFIleMgr IFIleMgr;

#endif 	/* __IFIleMgr_FWD_DEFINED__ */


#ifndef __FIleMgr_FWD_DEFINED__
#define __FIleMgr_FWD_DEFINED__

#ifdef __cplusplus
typedef class FIleMgr FIleMgr;
#else
typedef struct FIleMgr FIleMgr;
#endif /* __cplusplus */

#endif 	/* __FIleMgr_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "shobjidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IFIleMgr_INTERFACE_DEFINED__
#define __IFIleMgr_INTERFACE_DEFINED__

/* interface IFIleMgr */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IFIleMgr;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6c5fcba2-00c0-4483-ba82-a2e3d71486f7")
    IFIleMgr : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE getFilesList( 
            /* [in] */ BSTR filePath,
            /* [in] */ BSTR Patterns) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetResult( 
            /* [retval][out] */ SAFEARRAY * *Result) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE getFilePath( 
            /* [retval][out] */ BSTR *filePath) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_BlockingQueue( 
            /* [out][in] */ BSTR *bq,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_BlockingQueue( 
            /* [out][in] */ BSTR *bq,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE processgetresult( 
            /* [in] */ BSTR flag,
            /* [retval][out] */ BSTR *outFile) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IFIleMgrVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFIleMgr * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFIleMgr * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFIleMgr * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFIleMgr * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFIleMgr * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFIleMgr * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFIleMgr * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *getFilesList )( 
            IFIleMgr * This,
            /* [in] */ BSTR filePath,
            /* [in] */ BSTR Patterns);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *GetResult )( 
            IFIleMgr * This,
            /* [retval][out] */ SAFEARRAY * *Result);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *getFilePath )( 
            IFIleMgr * This,
            /* [retval][out] */ BSTR *filePath);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_BlockingQueue )( 
            IFIleMgr * This,
            /* [out][in] */ BSTR *bq,
            /* [retval][out] */ BSTR *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_BlockingQueue )( 
            IFIleMgr * This,
            /* [out][in] */ BSTR *bq,
            /* [in] */ BSTR newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *processgetresult )( 
            IFIleMgr * This,
            /* [in] */ BSTR flag,
            /* [retval][out] */ BSTR *outFile);
        
        END_INTERFACE
    } IFIleMgrVtbl;

    interface IFIleMgr
    {
        CONST_VTBL struct IFIleMgrVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFIleMgr_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFIleMgr_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFIleMgr_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFIleMgr_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFIleMgr_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFIleMgr_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFIleMgr_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFIleMgr_getFilesList(This,filePath,Patterns)	\
    ( (This)->lpVtbl -> getFilesList(This,filePath,Patterns) ) 

#define IFIleMgr_GetResult(This,Result)	\
    ( (This)->lpVtbl -> GetResult(This,Result) ) 

#define IFIleMgr_getFilePath(This,filePath)	\
    ( (This)->lpVtbl -> getFilePath(This,filePath) ) 

#define IFIleMgr_get_BlockingQueue(This,bq,pVal)	\
    ( (This)->lpVtbl -> get_BlockingQueue(This,bq,pVal) ) 

#define IFIleMgr_put_BlockingQueue(This,bq,newVal)	\
    ( (This)->lpVtbl -> put_BlockingQueue(This,bq,newVal) ) 

#define IFIleMgr_processgetresult(This,flag,outFile)	\
    ( (This)->lpVtbl -> processgetresult(This,flag,outFile) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFIleMgr_INTERFACE_DEFINED__ */



#ifndef __PrFIleManagerLib_LIBRARY_DEFINED__
#define __PrFIleManagerLib_LIBRARY_DEFINED__

/* library PrFIleManagerLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_PrFIleManagerLib;

EXTERN_C const CLSID CLSID_FIleMgr;

#ifdef __cplusplus

class DECLSPEC_UUID("e06afb58-1815-4e32-9a30-6890b997434f")
FIleMgr;
#endif
#endif /* __PrFIleManagerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long *, unsigned long            , LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long *, unsigned char *, LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long *, unsigned char *, LPSAFEARRAY * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long *, LPSAFEARRAY * ); 

unsigned long             __RPC_USER  BSTR_UserSize64(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal64(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal64(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree64(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize64(     unsigned long *, unsigned long            , LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserMarshal64(  unsigned long *, unsigned char *, LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserUnmarshal64(unsigned long *, unsigned char *, LPSAFEARRAY * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree64(     unsigned long *, LPSAFEARRAY * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


