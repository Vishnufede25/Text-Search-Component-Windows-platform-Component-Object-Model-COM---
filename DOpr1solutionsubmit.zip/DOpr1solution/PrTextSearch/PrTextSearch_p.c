

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Mon Jan 18 22:14:07 2038
 */
/* Compiler settings for PrTextSearch.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_)


#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/
#pragma warning( disable: 4152 )  /* function/data pointer conversion in expression */
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */

#pragma optimize("", off ) 

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 475
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif /* __RPCPROXY_H_VERSION__ */


#include "PrTextSearch_i.h"

#define TYPE_FORMAT_STRING_SIZE   1229                              
#define PROC_FORMAT_STRING_SIZE   223                               
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   2            

typedef struct _PrTextSearch_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } PrTextSearch_MIDL_TYPE_FORMAT_STRING;

typedef struct _PrTextSearch_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } PrTextSearch_MIDL_PROC_FORMAT_STRING;

typedef struct _PrTextSearch_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } PrTextSearch_MIDL_EXPR_FORMAT_STRING;


static const RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const PrTextSearch_MIDL_TYPE_FORMAT_STRING PrTextSearch__MIDL_TypeFormatString;
extern const PrTextSearch_MIDL_PROC_FORMAT_STRING PrTextSearch__MIDL_ProcFormatString;
extern const PrTextSearch_MIDL_EXPR_FORMAT_STRING PrTextSearch__MIDL_ExprFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ItextSearch_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ItextSearch_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif
#if !(TARGET_IS_NT60_OR_LATER)
#error You need Windows Vista or later to run this stub because it uses these features:
#error   forced complex structure or array, new range semantics, compiled for Windows Vista.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will fail with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const PrTextSearch_MIDL_PROC_FORMAT_STRING PrTextSearch__MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure getFileMgrPtr */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
/*  8 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x8 ),	/* 8 */
/* 14 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 16 */	0x8,		/* 8 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 18 */	NdrFcShort( 0x0 ),	/* 0 */
/* 20 */	NdrFcShort( 0x0 ),	/* 0 */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pFilePtr */

/* 24 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 26 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 28 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Return value */

/* 30 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 32 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 34 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetResult */

/* 36 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 38 */	NdrFcLong( 0x0 ),	/* 0 */
/* 42 */	NdrFcShort( 0x8 ),	/* 8 */
/* 44 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 46 */	NdrFcShort( 0x0 ),	/* 0 */
/* 48 */	NdrFcShort( 0x8 ),	/* 8 */
/* 50 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 52 */	0x8,		/* 8 */
			0x43,		/* Ext Flags:  new corr desc, clt corr check, has range on conformance */
/* 54 */	NdrFcShort( 0x1 ),	/* 1 */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter Result */

/* 60 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 62 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 64 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 66 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 68 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 70 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetFinalResults */

/* 72 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 74 */	NdrFcLong( 0x0 ),	/* 0 */
/* 78 */	NdrFcShort( 0x9 ),	/* 9 */
/* 80 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 82 */	NdrFcShort( 0x0 ),	/* 0 */
/* 84 */	NdrFcShort( 0x8 ),	/* 8 */
/* 86 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 88 */	0x8,		/* 8 */
			0x47,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, has range on conformance */
/* 90 */	NdrFcShort( 0x1 ),	/* 1 */
/* 92 */	NdrFcShort( 0x1 ),	/* 1 */
/* 94 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter regexline */

/* 96 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 98 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 100 */	NdrFcShort( 0x4a ),	/* Type Offset=74 */

	/* Parameter Result */

/* 102 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 104 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 106 */	NdrFcShort( 0x4c2 ),	/* Type Offset=1218 */

	/* Return value */

/* 108 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 110 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 112 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure getFilesArray */

/* 114 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 116 */	NdrFcLong( 0x0 ),	/* 0 */
/* 120 */	NdrFcShort( 0xa ),	/* 10 */
/* 122 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 124 */	NdrFcShort( 0x0 ),	/* 0 */
/* 126 */	NdrFcShort( 0x8 ),	/* 8 */
/* 128 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 130 */	0x8,		/* 8 */
			0x43,		/* Ext Flags:  new corr desc, clt corr check, has range on conformance */
/* 132 */	NdrFcShort( 0x1 ),	/* 1 */
/* 134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 136 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter Filess */

/* 138 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 140 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 142 */	NdrFcShort( 0x4c2 ),	/* Type Offset=1218 */

	/* Return value */

/* 144 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 146 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 148 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure putiInFilesArray */

/* 150 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 152 */	NdrFcLong( 0x0 ),	/* 0 */
/* 156 */	NdrFcShort( 0xb ),	/* 11 */
/* 158 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 160 */	NdrFcShort( 0x0 ),	/* 0 */
/* 162 */	NdrFcShort( 0x8 ),	/* 8 */
/* 164 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 166 */	0x8,		/* 8 */
			0x45,		/* Ext Flags:  new corr desc, srv corr check, has range on conformance */
/* 168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 170 */	NdrFcShort( 0x1 ),	/* 1 */
/* 172 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter itemBstr */

/* 174 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 176 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 178 */	NdrFcShort( 0x4a ),	/* Type Offset=74 */

	/* Return value */

/* 180 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 182 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 184 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure mainProcess */

/* 186 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 188 */	NdrFcLong( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0xc ),	/* 12 */
/* 194 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 196 */	NdrFcShort( 0x0 ),	/* 0 */
/* 198 */	NdrFcShort( 0x8 ),	/* 8 */
/* 200 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 202 */	0x8,		/* 8 */
			0x45,		/* Ext Flags:  new corr desc, srv corr check, has range on conformance */
/* 204 */	NdrFcShort( 0x0 ),	/* 0 */
/* 206 */	NdrFcShort( 0x1 ),	/* 1 */
/* 208 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter regexstr */

/* 210 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 212 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 214 */	NdrFcShort( 0x4a ),	/* Type Offset=74 */

	/* Return value */

/* 216 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 218 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 220 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const PrTextSearch_MIDL_TYPE_FORMAT_STRING PrTextSearch__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/*  4 */	NdrFcLong( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x0 ),	/* 0 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 14 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 16 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 18 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 20 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 22 */	NdrFcShort( 0x26 ),	/* Offset= 38 (60) */
/* 24 */	
			0x13, 0x0,	/* FC_OP */
/* 26 */	NdrFcShort( 0x18 ),	/* Offset= 24 (50) */
/* 28 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 30 */	NdrFcShort( 0x2 ),	/* 2 */
/* 32 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 34 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 36 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 38 */	0x0 , 
			0x0,		/* 0 */
/* 40 */	NdrFcLong( 0x0 ),	/* 0 */
/* 44 */	NdrFcLong( 0x0 ),	/* 0 */
/* 48 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 50 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 52 */	NdrFcShort( 0x8 ),	/* 8 */
/* 54 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (28) */
/* 56 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 58 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 60 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 62 */	NdrFcShort( 0x0 ),	/* 0 */
/* 64 */	NdrFcShort( 0x4 ),	/* 4 */
/* 66 */	NdrFcShort( 0x0 ),	/* 0 */
/* 68 */	NdrFcShort( 0xffd4 ),	/* Offset= -44 (24) */
/* 70 */	
			0x12, 0x0,	/* FC_UP */
/* 72 */	NdrFcShort( 0xffea ),	/* Offset= -22 (50) */
/* 74 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 76 */	NdrFcShort( 0x0 ),	/* 0 */
/* 78 */	NdrFcShort( 0x4 ),	/* 4 */
/* 80 */	NdrFcShort( 0x0 ),	/* 0 */
/* 82 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (70) */
/* 84 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 86 */	NdrFcShort( 0x46c ),	/* Offset= 1132 (1218) */
/* 88 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 90 */	NdrFcShort( 0x2 ),	/* Offset= 2 (92) */
/* 92 */	
			0x13, 0x0,	/* FC_OP */
/* 94 */	NdrFcShort( 0x452 ),	/* Offset= 1106 (1200) */
/* 96 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x49,		/* 73 */
/* 98 */	NdrFcShort( 0x18 ),	/* 24 */
/* 100 */	NdrFcShort( 0xa ),	/* 10 */
/* 102 */	NdrFcLong( 0x8 ),	/* 8 */
/* 106 */	NdrFcShort( 0x64 ),	/* Offset= 100 (206) */
/* 108 */	NdrFcLong( 0xd ),	/* 13 */
/* 112 */	NdrFcShort( 0x9c ),	/* Offset= 156 (268) */
/* 114 */	NdrFcLong( 0x9 ),	/* 9 */
/* 118 */	NdrFcShort( 0xe2 ),	/* Offset= 226 (344) */
/* 120 */	NdrFcLong( 0xc ),	/* 12 */
/* 124 */	NdrFcShort( 0x2fa ),	/* Offset= 762 (886) */
/* 126 */	NdrFcLong( 0x24 ),	/* 36 */
/* 130 */	NdrFcShort( 0x32e ),	/* Offset= 814 (944) */
/* 132 */	NdrFcLong( 0x800d ),	/* 32781 */
/* 136 */	NdrFcShort( 0x34a ),	/* Offset= 842 (978) */
/* 138 */	NdrFcLong( 0x10 ),	/* 16 */
/* 142 */	NdrFcShort( 0x36e ),	/* Offset= 878 (1020) */
/* 144 */	NdrFcLong( 0x2 ),	/* 2 */
/* 148 */	NdrFcShort( 0x392 ),	/* Offset= 914 (1062) */
/* 150 */	NdrFcLong( 0x3 ),	/* 3 */
/* 154 */	NdrFcShort( 0x3b6 ),	/* Offset= 950 (1104) */
/* 156 */	NdrFcLong( 0x14 ),	/* 20 */
/* 160 */	NdrFcShort( 0x3da ),	/* Offset= 986 (1146) */
/* 162 */	NdrFcShort( 0xffff ),	/* Offset= -1 (161) */
/* 164 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 166 */	NdrFcShort( 0x4 ),	/* 4 */
/* 168 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 172 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 174 */	0x0 , 
			0x0,		/* 0 */
/* 176 */	NdrFcLong( 0x0 ),	/* 0 */
/* 180 */	NdrFcLong( 0x0 ),	/* 0 */
/* 184 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 186 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 188 */	NdrFcShort( 0x4 ),	/* 4 */
/* 190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0x1 ),	/* 1 */
/* 194 */	NdrFcShort( 0x0 ),	/* 0 */
/* 196 */	NdrFcShort( 0x0 ),	/* 0 */
/* 198 */	0x13, 0x0,	/* FC_OP */
/* 200 */	NdrFcShort( 0xff6a ),	/* Offset= -150 (50) */
/* 202 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 204 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 206 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 208 */	NdrFcShort( 0x8 ),	/* 8 */
/* 210 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 212 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 214 */	NdrFcShort( 0x4 ),	/* 4 */
/* 216 */	NdrFcShort( 0x4 ),	/* 4 */
/* 218 */	0x11, 0x0,	/* FC_RP */
/* 220 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (164) */
/* 222 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 224 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 226 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 228 */	NdrFcShort( 0x0 ),	/* 0 */
/* 230 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 232 */	NdrFcShort( 0x0 ),	/* 0 */
/* 234 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 236 */	0x0 , 
			0x0,		/* 0 */
/* 238 */	NdrFcLong( 0x0 ),	/* 0 */
/* 242 */	NdrFcLong( 0x0 ),	/* 0 */
/* 246 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 250 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 252 */	0x0 , 
			0x0,		/* 0 */
/* 254 */	NdrFcLong( 0x0 ),	/* 0 */
/* 258 */	NdrFcLong( 0x0 ),	/* 0 */
/* 262 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 264 */	NdrFcShort( 0xfefa ),	/* Offset= -262 (2) */
/* 266 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 268 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 270 */	NdrFcShort( 0x8 ),	/* 8 */
/* 272 */	NdrFcShort( 0x0 ),	/* 0 */
/* 274 */	NdrFcShort( 0x6 ),	/* Offset= 6 (280) */
/* 276 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 278 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 280 */	
			0x11, 0x0,	/* FC_RP */
/* 282 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (226) */
/* 284 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 286 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 290 */	NdrFcShort( 0x0 ),	/* 0 */
/* 292 */	NdrFcShort( 0x0 ),	/* 0 */
/* 294 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 296 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 298 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 300 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 302 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 304 */	NdrFcShort( 0x0 ),	/* 0 */
/* 306 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 308 */	NdrFcShort( 0x0 ),	/* 0 */
/* 310 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 312 */	0x0 , 
			0x0,		/* 0 */
/* 314 */	NdrFcLong( 0x0 ),	/* 0 */
/* 318 */	NdrFcLong( 0x0 ),	/* 0 */
/* 322 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 326 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 328 */	0x0 , 
			0x0,		/* 0 */
/* 330 */	NdrFcLong( 0x0 ),	/* 0 */
/* 334 */	NdrFcLong( 0x0 ),	/* 0 */
/* 338 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 340 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (284) */
/* 342 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 344 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 346 */	NdrFcShort( 0x8 ),	/* 8 */
/* 348 */	NdrFcShort( 0x0 ),	/* 0 */
/* 350 */	NdrFcShort( 0x6 ),	/* Offset= 6 (356) */
/* 352 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 354 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 356 */	
			0x11, 0x0,	/* FC_RP */
/* 358 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (302) */
/* 360 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x9,		/* FC_ULONG */
/* 362 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 364 */	NdrFcShort( 0xfff8 ),	/* -8 */
/* 366 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 368 */	0x0 , 
			0x0,		/* 0 */
/* 370 */	NdrFcLong( 0x0 ),	/* 0 */
/* 374 */	NdrFcLong( 0x0 ),	/* 0 */
/* 378 */	NdrFcShort( 0x2 ),	/* Offset= 2 (380) */
/* 380 */	NdrFcShort( 0x10 ),	/* 16 */
/* 382 */	NdrFcShort( 0x2f ),	/* 47 */
/* 384 */	NdrFcLong( 0x14 ),	/* 20 */
/* 388 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 390 */	NdrFcLong( 0x3 ),	/* 3 */
/* 394 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 396 */	NdrFcLong( 0x11 ),	/* 17 */
/* 400 */	NdrFcShort( 0x8001 ),	/* Simple arm type: FC_BYTE */
/* 402 */	NdrFcLong( 0x2 ),	/* 2 */
/* 406 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 408 */	NdrFcLong( 0x4 ),	/* 4 */
/* 412 */	NdrFcShort( 0x800a ),	/* Simple arm type: FC_FLOAT */
/* 414 */	NdrFcLong( 0x5 ),	/* 5 */
/* 418 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 420 */	NdrFcLong( 0xb ),	/* 11 */
/* 424 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 426 */	NdrFcLong( 0xa ),	/* 10 */
/* 430 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 432 */	NdrFcLong( 0x6 ),	/* 6 */
/* 436 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (668) */
/* 438 */	NdrFcLong( 0x7 ),	/* 7 */
/* 442 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 444 */	NdrFcLong( 0x8 ),	/* 8 */
/* 448 */	NdrFcShort( 0xfe58 ),	/* Offset= -424 (24) */
/* 450 */	NdrFcLong( 0xd ),	/* 13 */
/* 454 */	NdrFcShort( 0xfe3c ),	/* Offset= -452 (2) */
/* 456 */	NdrFcLong( 0x9 ),	/* 9 */
/* 460 */	NdrFcShort( 0xff50 ),	/* Offset= -176 (284) */
/* 462 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 466 */	NdrFcShort( 0xd0 ),	/* Offset= 208 (674) */
/* 468 */	NdrFcLong( 0x24 ),	/* 36 */
/* 472 */	NdrFcShort( 0xd2 ),	/* Offset= 210 (682) */
/* 474 */	NdrFcLong( 0x4024 ),	/* 16420 */
/* 478 */	NdrFcShort( 0xcc ),	/* Offset= 204 (682) */
/* 480 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 484 */	NdrFcShort( 0x106 ),	/* Offset= 262 (746) */
/* 486 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 490 */	NdrFcShort( 0x104 ),	/* Offset= 260 (750) */
/* 492 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 496 */	NdrFcShort( 0x102 ),	/* Offset= 258 (754) */
/* 498 */	NdrFcLong( 0x4014 ),	/* 16404 */
/* 502 */	NdrFcShort( 0x100 ),	/* Offset= 256 (758) */
/* 504 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 508 */	NdrFcShort( 0xfe ),	/* Offset= 254 (762) */
/* 510 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 514 */	NdrFcShort( 0xfc ),	/* Offset= 252 (766) */
/* 516 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 520 */	NdrFcShort( 0xe6 ),	/* Offset= 230 (750) */
/* 522 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 526 */	NdrFcShort( 0xe4 ),	/* Offset= 228 (754) */
/* 528 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 532 */	NdrFcShort( 0xee ),	/* Offset= 238 (770) */
/* 534 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 538 */	NdrFcShort( 0xe4 ),	/* Offset= 228 (766) */
/* 540 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 544 */	NdrFcShort( 0xe6 ),	/* Offset= 230 (774) */
/* 546 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 550 */	NdrFcShort( 0xe4 ),	/* Offset= 228 (778) */
/* 552 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 556 */	NdrFcShort( 0xe2 ),	/* Offset= 226 (782) */
/* 558 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 562 */	NdrFcShort( 0xe0 ),	/* Offset= 224 (786) */
/* 564 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 568 */	NdrFcShort( 0xe6 ),	/* Offset= 230 (798) */
/* 570 */	NdrFcLong( 0x10 ),	/* 16 */
/* 574 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 576 */	NdrFcLong( 0x12 ),	/* 18 */
/* 580 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 582 */	NdrFcLong( 0x13 ),	/* 19 */
/* 586 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 588 */	NdrFcLong( 0x15 ),	/* 21 */
/* 592 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 594 */	NdrFcLong( 0x16 ),	/* 22 */
/* 598 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 600 */	NdrFcLong( 0x17 ),	/* 23 */
/* 604 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 606 */	NdrFcLong( 0xe ),	/* 14 */
/* 610 */	NdrFcShort( 0xc4 ),	/* Offset= 196 (806) */
/* 612 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 616 */	NdrFcShort( 0xc8 ),	/* Offset= 200 (816) */
/* 618 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 622 */	NdrFcShort( 0xc6 ),	/* Offset= 198 (820) */
/* 624 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 628 */	NdrFcShort( 0x7a ),	/* Offset= 122 (750) */
/* 630 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 634 */	NdrFcShort( 0x78 ),	/* Offset= 120 (754) */
/* 636 */	NdrFcLong( 0x4015 ),	/* 16405 */
/* 640 */	NdrFcShort( 0x76 ),	/* Offset= 118 (758) */
/* 642 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 646 */	NdrFcShort( 0x6c ),	/* Offset= 108 (754) */
/* 648 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 652 */	NdrFcShort( 0x66 ),	/* Offset= 102 (754) */
/* 654 */	NdrFcLong( 0x0 ),	/* 0 */
/* 658 */	NdrFcShort( 0x0 ),	/* Offset= 0 (658) */
/* 660 */	NdrFcLong( 0x1 ),	/* 1 */
/* 664 */	NdrFcShort( 0x0 ),	/* Offset= 0 (664) */
/* 666 */	NdrFcShort( 0xffff ),	/* Offset= -1 (665) */
/* 668 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 670 */	NdrFcShort( 0x8 ),	/* 8 */
/* 672 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 674 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 676 */	NdrFcShort( 0x2 ),	/* Offset= 2 (678) */
/* 678 */	
			0x13, 0x0,	/* FC_OP */
/* 680 */	NdrFcShort( 0x208 ),	/* Offset= 520 (1200) */
/* 682 */	
			0x13, 0x0,	/* FC_OP */
/* 684 */	NdrFcShort( 0x2a ),	/* Offset= 42 (726) */
/* 686 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 688 */	NdrFcLong( 0x2f ),	/* 47 */
/* 692 */	NdrFcShort( 0x0 ),	/* 0 */
/* 694 */	NdrFcShort( 0x0 ),	/* 0 */
/* 696 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 698 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 700 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 702 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 704 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 706 */	NdrFcShort( 0x1 ),	/* 1 */
/* 708 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 710 */	NdrFcShort( 0x4 ),	/* 4 */
/* 712 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 714 */	0x0 , 
			0x0,		/* 0 */
/* 716 */	NdrFcLong( 0x0 ),	/* 0 */
/* 720 */	NdrFcLong( 0x0 ),	/* 0 */
/* 724 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 726 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 728 */	NdrFcShort( 0x10 ),	/* 16 */
/* 730 */	NdrFcShort( 0x0 ),	/* 0 */
/* 732 */	NdrFcShort( 0xa ),	/* Offset= 10 (742) */
/* 734 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 736 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 738 */	NdrFcShort( 0xffcc ),	/* Offset= -52 (686) */
/* 740 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 742 */	
			0x13, 0x20,	/* FC_OP [maybenull_sizeis] */
/* 744 */	NdrFcShort( 0xffd8 ),	/* Offset= -40 (704) */
/* 746 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 748 */	0x1,		/* FC_BYTE */
			0x5c,		/* FC_PAD */
/* 750 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 752 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 754 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 756 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 758 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 760 */	0xb,		/* FC_HYPER */
			0x5c,		/* FC_PAD */
/* 762 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 764 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 766 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 768 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 770 */	
			0x13, 0x0,	/* FC_OP */
/* 772 */	NdrFcShort( 0xff98 ),	/* Offset= -104 (668) */
/* 774 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 776 */	NdrFcShort( 0xfd10 ),	/* Offset= -752 (24) */
/* 778 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 780 */	NdrFcShort( 0xfcf6 ),	/* Offset= -778 (2) */
/* 782 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 784 */	NdrFcShort( 0xfe0c ),	/* Offset= -500 (284) */
/* 786 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 788 */	NdrFcShort( 0x2 ),	/* Offset= 2 (790) */
/* 790 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 792 */	NdrFcShort( 0x2 ),	/* Offset= 2 (794) */
/* 794 */	
			0x13, 0x0,	/* FC_OP */
/* 796 */	NdrFcShort( 0x194 ),	/* Offset= 404 (1200) */
/* 798 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 800 */	NdrFcShort( 0x2 ),	/* Offset= 2 (802) */
/* 802 */	
			0x13, 0x0,	/* FC_OP */
/* 804 */	NdrFcShort( 0x14 ),	/* Offset= 20 (824) */
/* 806 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 808 */	NdrFcShort( 0x10 ),	/* 16 */
/* 810 */	0x6,		/* FC_SHORT */
			0x1,		/* FC_BYTE */
/* 812 */	0x1,		/* FC_BYTE */
			0x8,		/* FC_LONG */
/* 814 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 816 */	
			0x13, 0x0,	/* FC_OP */
/* 818 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (806) */
/* 820 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 822 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 824 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 826 */	NdrFcShort( 0x20 ),	/* 32 */
/* 828 */	NdrFcShort( 0x0 ),	/* 0 */
/* 830 */	NdrFcShort( 0x0 ),	/* Offset= 0 (830) */
/* 832 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 834 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 836 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 838 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 840 */	NdrFcShort( 0xfe20 ),	/* Offset= -480 (360) */
/* 842 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 844 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 846 */	NdrFcShort( 0x4 ),	/* 4 */
/* 848 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 850 */	NdrFcShort( 0x0 ),	/* 0 */
/* 852 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 854 */	0x0 , 
			0x0,		/* 0 */
/* 856 */	NdrFcLong( 0x0 ),	/* 0 */
/* 860 */	NdrFcLong( 0x0 ),	/* 0 */
/* 864 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 866 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 868 */	NdrFcShort( 0x4 ),	/* 4 */
/* 870 */	NdrFcShort( 0x0 ),	/* 0 */
/* 872 */	NdrFcShort( 0x1 ),	/* 1 */
/* 874 */	NdrFcShort( 0x0 ),	/* 0 */
/* 876 */	NdrFcShort( 0x0 ),	/* 0 */
/* 878 */	0x13, 0x0,	/* FC_OP */
/* 880 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (824) */
/* 882 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 884 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 886 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 888 */	NdrFcShort( 0x8 ),	/* 8 */
/* 890 */	NdrFcShort( 0x0 ),	/* 0 */
/* 892 */	NdrFcShort( 0x6 ),	/* Offset= 6 (898) */
/* 894 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 896 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 898 */	
			0x11, 0x0,	/* FC_RP */
/* 900 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (844) */
/* 902 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 904 */	NdrFcShort( 0x4 ),	/* 4 */
/* 906 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 908 */	NdrFcShort( 0x0 ),	/* 0 */
/* 910 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 912 */	0x0 , 
			0x0,		/* 0 */
/* 914 */	NdrFcLong( 0x0 ),	/* 0 */
/* 918 */	NdrFcLong( 0x0 ),	/* 0 */
/* 922 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 924 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 926 */	NdrFcShort( 0x4 ),	/* 4 */
/* 928 */	NdrFcShort( 0x0 ),	/* 0 */
/* 930 */	NdrFcShort( 0x1 ),	/* 1 */
/* 932 */	NdrFcShort( 0x0 ),	/* 0 */
/* 934 */	NdrFcShort( 0x0 ),	/* 0 */
/* 936 */	0x13, 0x0,	/* FC_OP */
/* 938 */	NdrFcShort( 0xff2c ),	/* Offset= -212 (726) */
/* 940 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 942 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 944 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 946 */	NdrFcShort( 0x8 ),	/* 8 */
/* 948 */	NdrFcShort( 0x0 ),	/* 0 */
/* 950 */	NdrFcShort( 0x6 ),	/* Offset= 6 (956) */
/* 952 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 954 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 956 */	
			0x11, 0x0,	/* FC_RP */
/* 958 */	NdrFcShort( 0xffc8 ),	/* Offset= -56 (902) */
/* 960 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 962 */	NdrFcShort( 0x8 ),	/* 8 */
/* 964 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 966 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 968 */	NdrFcShort( 0x10 ),	/* 16 */
/* 970 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 972 */	0x6,		/* FC_SHORT */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 974 */	0x0,		/* 0 */
			NdrFcShort( 0xfff1 ),	/* Offset= -15 (960) */
			0x5b,		/* FC_END */
/* 978 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 980 */	NdrFcShort( 0x18 ),	/* 24 */
/* 982 */	NdrFcShort( 0x0 ),	/* 0 */
/* 984 */	NdrFcShort( 0xa ),	/* Offset= 10 (994) */
/* 986 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 988 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 990 */	NdrFcShort( 0xffe8 ),	/* Offset= -24 (966) */
/* 992 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 994 */	
			0x11, 0x0,	/* FC_RP */
/* 996 */	NdrFcShort( 0xfcfe ),	/* Offset= -770 (226) */
/* 998 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 1000 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1002 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 1004 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1006 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 1008 */	0x0 , 
			0x0,		/* 0 */
/* 1010 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1014 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1018 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 1020 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 1022 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1024 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 1026 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 1028 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1030 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1032 */	0x13, 0x20,	/* FC_OP [maybenull_sizeis] */
/* 1034 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (998) */
/* 1036 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 1038 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 1040 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 1042 */	NdrFcShort( 0x2 ),	/* 2 */
/* 1044 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 1046 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1048 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 1050 */	0x0 , 
			0x0,		/* 0 */
/* 1052 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1056 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1060 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 1062 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 1064 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1066 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 1068 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 1070 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1072 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1074 */	0x13, 0x20,	/* FC_OP [maybenull_sizeis] */
/* 1076 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (1040) */
/* 1078 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 1080 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 1082 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 1084 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1086 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 1088 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1090 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 1092 */	0x0 , 
			0x0,		/* 0 */
/* 1094 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1098 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1102 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 1104 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 1106 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1108 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 1110 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 1112 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1114 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1116 */	0x13, 0x20,	/* FC_OP [maybenull_sizeis] */
/* 1118 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (1082) */
/* 1120 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 1122 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 1124 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 1126 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1128 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 1130 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1132 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 1134 */	0x0 , 
			0x0,		/* 0 */
/* 1136 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1140 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1144 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 1146 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 1148 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1150 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 1152 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 1154 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1156 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1158 */	0x13, 0x20,	/* FC_OP [maybenull_sizeis] */
/* 1160 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (1124) */
/* 1162 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 1164 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 1166 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 1168 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1170 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 1172 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1174 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 1176 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1178 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 1180 */	NdrFcShort( 0xffd8 ),	/* -40 */
/* 1182 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 1184 */	0x0 , 
			0x0,		/* 0 */
/* 1186 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1190 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1194 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 1196 */	NdrFcShort( 0xffe2 ),	/* Offset= -30 (1166) */
/* 1198 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1200 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 1202 */	NdrFcShort( 0x28 ),	/* 40 */
/* 1204 */	NdrFcShort( 0xffe2 ),	/* Offset= -30 (1174) */
/* 1206 */	NdrFcShort( 0x0 ),	/* Offset= 0 (1206) */
/* 1208 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1210 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 1212 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 1214 */	NdrFcShort( 0xfba2 ),	/* Offset= -1118 (96) */
/* 1216 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1218 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1220 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1222 */	NdrFcShort( 0x4 ),	/* 4 */
/* 1224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1226 */	NdrFcShort( 0xfb8e ),	/* Offset= -1138 (88) */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            BSTR_UserSize
            ,BSTR_UserMarshal
            ,BSTR_UserUnmarshal
            ,BSTR_UserFree
            },
            {
            LPSAFEARRAY_UserSize
            ,LPSAFEARRAY_UserMarshal
            ,LPSAFEARRAY_UserUnmarshal
            ,LPSAFEARRAY_UserFree
            }

        };



/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ItextSearch, ver. 0.0,
   GUID={0x8e2683f2,0xb043,0x4f18,{0xb0,0x49,0x70,0xe1,0x8b,0x9a,0x3c,0xec}} */

#pragma code_seg(".orpc")
static const unsigned short ItextSearch_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    36,
    72,
    114,
    150,
    186
    };

static const MIDL_STUBLESS_PROXY_INFO ItextSearch_ProxyInfo =
    {
    &Object_StubDesc,
    PrTextSearch__MIDL_ProcFormatString.Format,
    &ItextSearch_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ItextSearch_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    PrTextSearch__MIDL_ProcFormatString.Format,
    &ItextSearch_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(13) _ItextSearchProxyVtbl = 
{
    &ItextSearch_ProxyInfo,
    &IID_ItextSearch,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::getFileMgrPtr */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::GetResult */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::GetFinalResults */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::getFilesArray */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::putiInFilesArray */ ,
    (void *) (INT_PTR) -1 /* ItextSearch::mainProcess */
};


static const PRPC_STUB_FUNCTION ItextSearch_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ItextSearchStubVtbl =
{
    &IID_ItextSearch,
    &ItextSearch_ServerInfo,
    13,
    &ItextSearch_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    PrTextSearch__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x60001, /* Ndr library version */
    0,
    0x801026e, /* MIDL Version 8.1.622 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0
    };

const CInterfaceProxyVtbl * const _PrTextSearch_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ItextSearchProxyVtbl,
    0
};

const CInterfaceStubVtbl * const _PrTextSearch_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ItextSearchStubVtbl,
    0
};

PCInterfaceName const _PrTextSearch_InterfaceNamesList[] = 
{
    "ItextSearch",
    0
};

const IID *  const _PrTextSearch_BaseIIDList[] = 
{
    &IID_IDispatch,
    0
};


#define _PrTextSearch_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _PrTextSearch, pIID, n)

int __stdcall _PrTextSearch_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_PrTextSearch_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo PrTextSearch_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _PrTextSearch_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _PrTextSearch_StubVtblList,
    (const PCInterfaceName * ) & _PrTextSearch_InterfaceNamesList,
    (const IID ** ) & _PrTextSearch_BaseIIDList,
    & _PrTextSearch_IID_Lookup, 
    1,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#pragma optimize("", on )
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_) */

